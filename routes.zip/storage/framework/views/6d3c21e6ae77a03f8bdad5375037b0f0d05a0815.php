<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>How To Install Vue 3 in Laravel 9 with Vite</title>
	<?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body 
	style="background: #EDF2F7;"
>
	<div id="app"></div>

	<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\order-management-thinu\resources\views/app.blade.php ENDPATH**/ ?>