<?php
namespace App\Http\Controllers\Order;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Orders;
use Carbon\Carbon;

class OrderActionController extends Controller {
  public function getAllStatus() {
    $all_status =  Orders::distinct()->get(['status']);
    return $all_status;
  }

  public function getAllChannel() {
    $channels_array = [];
    $all_channel = Orders::distinct()->orderBy('channel', 'ASC')->get(['channel']);
    foreach($all_channel as $channel)
    {
      $exploded = explode("-",$channel->channel);
      if (str_contains($channel->channel, '-')) {
        if (!in_array("MAINCHANNEL_".$exploded[0], $channels_array)) {
          array_push($channels_array, "MAINCHANNEL_".$exploded[0]);
        }
        array_push($channels_array,$exploded[1]);
      }
      else {
        array_push($channels_array,$exploded[0]);
      }
    }
    return $channels_array;
  }

  public function getAllFlags() {
    $all_flags = Orders::distinct()->orderBy('flags', 'ASC')->get(['flags']);
    return $all_flags;
  }

  public function getGraphData(Request $request) {
    $monthStart = Carbon::parse(Carbon::now()->firstOfMonth()->toDateString());
    $monthEnd= Carbon::parse(Carbon::now()->lastOfMonth()->toDateString());
    $end_date = Carbon::now()->toDateString();
    $label_array =[];$val_array =[];
    if(empty($request->dataobj['sel_date']) or $request->dataobj['sel_date'] == "month") {
      $start_date = Carbon::now()->firstOfMonth()->toDateString();
      $period = $monthStart->range($monthEnd, 1, 'day');
      $query = Orders::select(DB::raw('DAY(date) day'),DB::raw('count(id) as count'))->where('date', '>=',$start_date)->where('date', '<=',$end_date)->groupBy('date')->get();
      foreach ($query as $row) {
        $value_array[$row->day] = $row->count;
      }
      foreach ($period as $dt) {
        $days = $dt->day;
        if(!empty($value_array[$days]))
        {
            array_push($val_array,$value_array[$days]);
        }
        else
        {
            array_push($val_array,0);
        }
        array_push($label_array,$days);
      }
    }
    else if($request->dataobj['sel_date'] == "week")
    {
      $start_date = Carbon::now()->startOfWeek(Carbon::SUNDAY)->toDateString();
      $weekStart = Carbon::parse(Carbon::now()->startOfWeek(Carbon::SUNDAY)->toDateString());
      $weekEnd= Carbon::parse(Carbon::now()->endOfWeek(Carbon::SATURDAY)->toDateString());

      $period = $weekStart->range($weekEnd, 1, 'day');
      $query = Orders::select(DB::raw('DAY(date) day'),DB::raw('count(id) as count'))->where('date', '>=',$start_date)->where('date', '<=',$end_date)->groupBy('date')->get('count');
      foreach ($query as $row) {
        $value_array[$row->day] = $row->count;
      }
      foreach ($period as $dt) {
        $days = $dt->day;
        $days_name = $dt->format('D');
        if(!empty($value_array[$days]))
        {
            array_push($val_array,$value_array[$days]);
        }
        else
        {
            array_push($val_array,0);
        }
        array_push($label_array,$days_name);
      }
    }
    else if($request->dataobj['sel_date'] == "year")
    {
      $start_date = Carbon::now()->firstOfYear()->toDateString();
      $query = Orders::select(DB::raw('MONTH(date) month'),DB::raw('count(id) as count'))->where('date', '>=',$start_date)->where('date', '<=',$end_date)->groupby('month')->get('count');
      foreach ($query as $row) {
        $value_array[$row->month] = $row->count;
      }
      for ($month=1; $month<=12; $month++) {
        $month_name = Carbon::parse("2022-".$month."-01")->format('M');
        if(!empty($value_array[$month]))
        {
            array_push($val_array,$value_array[$month]);
        }
        else
        {
            array_push($val_array,0);
        }
        array_push($label_array,$month_name);
      }
    }
    $result = ["yaxis" => $val_array, "xaxis" => $label_array];
    return $result;
  }

  public function getOrdersSummary(Request $request) {
    $end_date = Carbon::now()->toDateString();
    if(!empty($request->dataobj['sel_date'])) {
        if($request->dataobj['sel_date'] == "week"){ $start_date = Carbon::now()->startOfWeek(Carbon::SUNDAY)->toDateString(); }
        else if($request->dataobj['sel_date'] == "month"){ $start_date = Carbon::now()->firstOfMonth()->toDateString(); }
        else if($request->dataobj['sel_date'] == "year"){ $start_date = Carbon::now()->firstOfYear()->toDateString(); }
    }
    else {
        $start_date = Carbon::now()->firstOfMonth()->toDateString();
    }

    $query = Orders::select(DB::raw('count(id) as count'), DB::raw('SUM(quantity) as qty'), DB::raw('SUM(ordertotal) as sales'))->where('date', '>=',$start_date)->where('date', '<=',$end_date);

    if(!empty($request->dataobj['sel_status'])) { $query = $query->where('status', '=', $request->dataobj['sel_status']); }

    if(!empty($request->dataobj['sel_channel'])) { $query = $query->where('channel', 'like', '%' . $request->dataobj['sel_channel'] . '%'); }

    if(!empty($request->dataobj['sel_flag'])) { $query = $query->where('flags', 'like', $request->dataobj['sel_flag'] . '%'); }

    $tot_orders = $query->first();

    if($tot_orders->count > 0){ $result = ["count" => $tot_orders->count, "qty" => $tot_orders->qty, "sales" => $tot_orders->sales]; }
    else{ $result = ["count" =>0, "qty" => 0, "sales" => 0.00]; }

    return $result;
  }
}
